$(document).ready(function(){
	$("a.navLinks").animate({
		marginLeft: "50px",
		opacity: 1.0
	}, 1000, "easeOutBounce");
	$("p, h1, table, img, li").animate({
		opacity: 1.0
	}, 1000);
		
	//Hovering over nav links--------------------
	$("a.navLinks").mouseover(function(){
		$(this).animate({
			color:"#FFFFFF"
		}, 200);
	});
	$("a.navLinks").mouseout(function(){
		$(this).animate({
			color:"#333333"
		}, 200);
	});
	
	//Clicking on nav links----------------------
	$("a.navLinks").click(function(event){
		var toLoad = $(this).attr('href');
		
		$("p, h1, table, img, li").animate({
			opacity:0
		}, 500);
		$("a.navLinks").animate({
			opacity:0,
			marginLeft:"5px"
		}, 500);
		
		setTimeout(function(){window:location = toLoad}, 500);
		event.preventDefault();
	});
});